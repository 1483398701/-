<?php

?>
<hr>
<p class="am-padding-left">Copyright © 2014-2015 Seal All Rights Reserved</p>
